package application;

import java.io.IOException;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Pane;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;


public class SampleController {
	
	//first page
	int count = 0;
	
	@FXML
    private Pane rootPage;

	@FXML
    private Button enterBtn;

    @FXML
    private TextField keyword;
    
    @FXML
    private Label tryLabel;
    
    //second page
    @FXML
    private AnchorPane resultPage;

    @FXML
    private Button backBtn;

    @FXML
    private Label resultLabel;
    
    @FXML
    private Button tryBtn;
    
    //sign up page
    @FXML
    private AnchorPane registerPage;

    @FXML
    private Button registerBtn;
    
    //login page
    @FXML
    private AnchorPane loginPage;
    
    @FXML
    private Button loginBtn;
    
    @FXML
    private TextArea help;
    
    @FXML
    private Button helpBtn;
   
    @FXML
    private Button closeBtn;
    
    @FXML
    private void handleButton1Action(ActionEvent event) {

        System.out.println(keyword.getText());


    }	
    
    @FXML
    private void handleHelpAction(ActionEvent event) {
    	help.setVisible(true);
    }
    
    @FXML
    private void handleCloseAction(ActionEvent event) {
    	help.setVisible(false);
    }
    

    
    
    public static String searchWord;
    
    @FXML
    void display(ActionEvent event) {
    	try {
    		String strA = "";
    		String strB = "";
    		String result = "";
    		//String test = keyword.getText();
    		//webscraping part
            // connects to website, then get() fetches and parses html file
    		System.out.println(searchWord);
            Document doc = Jsoup.connect("https://unsplash.com/s/photos/" + searchWord).get();
            // we use this to grab each element tag
            Elements imageElements = doc.getElementsByTag("img");
            // for each element tag we print out the link to the source image
            for (Element element : imageElements) {
                System.out.println("src: "+element.attr("src"));
                
                //just for printing out urls on the application itself
                strA = "src: "+element.attr("src")+"\n";
                result = strB.concat(strA);
                strB = result;
            }
            //prints out all urls
            resultLabel.setText("Here are the results: \n" + result);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    //switch to new screen when search button is pressed
    @FXML
    void loadResult(ActionEvent event) throws IOException {
    	searchWord = keyword.getText();
    	AnchorPane pane = FXMLLoader.load(getClass().getResource("Result.fxml"));
    	rootPage.getChildren().setAll(pane);
    }
    
    //switch back to main search page when back button is pressed
    @FXML
    void goBack(ActionEvent event) throws IOException {
    	Pane pane = FXMLLoader.load(getClass().getResource("Sample.fxml"));
    	resultPage.getChildren().setAll(pane);
    }
    
  //switch to login screen when sign up button is pressed
    @FXML
    void goToLogin(ActionEvent event) throws IOException {
    	AnchorPane pane = FXMLLoader.load(getClass().getResource("Login.fxml"));
    	registerPage.getChildren().setAll(pane);
    }
    
  //switch to main screen when login button is pressed
    @FXML
    void goToMain(ActionEvent event) throws IOException {
    	Pane pane = FXMLLoader.load(getClass().getResource("Sample.fxml"));
    	loginPage.getChildren().setAll(pane);
    }
    

}
